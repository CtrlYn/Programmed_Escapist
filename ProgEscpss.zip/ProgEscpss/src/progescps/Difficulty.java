package progescps;


public enum Difficulty {
    EASY,
    NORMAL,
    HARD
}
