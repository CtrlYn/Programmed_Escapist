package progescps;

import java.io.*;


public class TurnBased_RPG {

    public static void main(String[] args) {
        System.out.println("Starting game (Swing UI)...");
        GameUI.launch();
    }
}